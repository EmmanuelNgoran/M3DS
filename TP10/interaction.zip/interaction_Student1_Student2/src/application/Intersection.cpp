#include "Intersection.h"

#include "Line.h"
#include "MeshObject3D.h"

using namespace p3d;
using namespace std;

Intersection::~Intersection() {

}

Intersection::Intersection() {
}









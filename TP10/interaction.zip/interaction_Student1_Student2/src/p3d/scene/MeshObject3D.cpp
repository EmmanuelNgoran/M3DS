#include "MeshObject3D.h"

using namespace p3d;

/*!
*
* @file
*
* @brief
* @author F. Aubert
*
*/


MeshObject3D::~MeshObject3D() {
}

MeshObject3D::MeshObject3D() {
}


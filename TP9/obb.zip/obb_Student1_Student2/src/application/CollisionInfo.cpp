#include "CollisionInfo.h"

CollisionInfo::CollisionInfo() {
  //ctor
}

CollisionInfo::~CollisionInfo() {
  //dtor
}

